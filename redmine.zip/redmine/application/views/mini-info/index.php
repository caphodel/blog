<style>
	#mini-info, #mini-info > *{
		text-align: center;
		vertical-align: middle;
	}
	#mini-info{
		display: inline-block;
		padding: 2px;
		cursor: pointer;
	}
</style>
<div id="mini-info">
	<div style="padding-top: 8px; padding-bottom: 8px;padding: 8px">
		<div class="circular" style="margin: 0 auto;display: inline-block;">
			<i class="fa fa-user fa-3x" aria-hidden="true"></i>
		</div>
		
		<div style="display: inline-block;">
			User no 1
		</div>
	</div>
</div>