<html>

<head>
	<link href="assets/css/main.css" rel="stylesheet" type="text/css" />
	<link href="assets/css/fonts.css" rel="stylesheet" type="text/css" />
	<link href="assets/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
	<style>
		#header > j-button{
			font-family: "Lato",sans-serif !important;
			font-size: 16px !important;
			font-weight: 600 !important;
		}
		#header > j-button{
			padding: 20px;
		}
		#header > j-button:hover{
			color: #4ABFDF !important;
		}
		body{
			background: #F7F8F9;
		}
	</style>
</head>

<body>
	
	<div id="header" style="height: 60px; background: #fff; border: 0px; box-shadow: 0 0.5px 0 0 #ffffff inset, 0 1px 2px 0 #B3B3B3;flex: 1 1 0;-webkit-box-flex: 1;-webkit-flex: 1;align-items: center;display: flex;">
		<j-button style="color: #525e61">Dashboard</j-button>
		<j-button style="color: #ABACB1">Project</j-button>
		<j-button style="color: #ABACB1">Task</j-button>
		<j-button style="color: #ABACB1">Calendar</j-button>
		<j-button style="color: #ABACB1">Document</j-button>
		<j-spacer style="flex: 1 1 0; -webkit-box-flex: 1; -webkit-flex: 1;"></j-spacer>
		<i class="fa fa-cog" style="color: #ABACB1; font-size: 16px;"></i>
		<div style="width: 200px;"></div>
	</div>
	
	<!--div id="header"><?php $this->view('base/logo'); ?><j-toolbar style="padding-left: 8px;vertical-align: middle;flex: 1 1 0;-webkit-box-flex: 1;-webkit-flex: 1;align-items: center;display: flex;"><j-button class="active">Dashboard</j-button><j-button>Issues</j-button></j-toolbar><?php $this->view('mini-info/index'); ?></div>
	<table id="body">
		<tbody>
			<tr>
				<td id="left"></td>
				<td id="right"></td>
			</tr>
		</tbody>
	</table-->
</body>

</html>
